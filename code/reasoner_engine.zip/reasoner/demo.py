"""
Interactive CLI Demo
Runs the full diagnostic reasoning loop with the Canon ink subsystem KB.

Usage:
    python demo.py [--xml path/to/datalog.xml] [--error 290020] [--error 250001]
"""

import sys
import json
import argparse
from typing import List, Tuple

from session_manager import DiagnosticSession


def print_header(text: str):
    print(f"\n{'='*70}")
    print(f"  {text}")
    print(f"{'='*70}")


def print_hypotheses(hypotheses: List[dict], max_show: int = 10):
    print(f"\n  {'Rank':<5} {'Probability':>11}  {'Root Cause'}")
    print(f"  {'─'*5} {'─'*11}  {'─'*50}")
    for h in hypotheses[:max_show]:
        marker = " ✗" if h["eliminated"] else ""
        bar_len = int(h["probability"] * 50)
        bar = "█" * bar_len + "░" * (50 - bar_len) if bar_len < 50 else "█" * 50
        print(f"  {h['rank']:<5} {h['probability']:>10.4%}  {h['rc_label'][:50]}{marker}")


def print_actions(actions: List[dict]):
    print(f"\n  {'#':<3} {'Score':>7} {'Type':<13} {'Action'}")
    print(f"  {'─'*3} {'─'*7} {'─'*13} {'─'*50}")
    for i, a in enumerate(actions, 1):
        if a["action_id"] is None:
            print(f"  {i:<3} {'—':>7} {'—':<13} {a['action_label']}")
            continue
        print(f"  {i:<3} {a['score']:>7.4f} {a['action_type']:<13} {a['action_label'][:50]}")
        print(f"      Rationale: {a['rationale'][:65]}")
        print(f"      Outcomes:  {a['outcomes']}")


def run_demo(kb_dir: str, xml_path: str = None, error_codes: List[str] = None, action_catalogue_path: str = None):
    """Run the interactive diagnostic demo."""
    
    print_header("Canon Ink Subsystem — Diagnostic Reasoner Demo")
    
    # Initialize session
    session = DiagnosticSession(kb_dir=kb_dir, lookback_days=90, action_catalogue_path=action_catalogue_path)
    print(f"\n{session.kb.summary()}")
    ts = session.tuning_stats
    print(f"  Likelihood tuning: tier1={ts['tier1']}, tier2={ts['tier2']}, tier3(placeholder)={ts['tier3']}")
    
    # Prepare initial observations from error codes
    user_obs: List[Tuple[str, str]] = []
    if error_codes:
        for code in error_codes:
            user_obs.append((code, "present"))
    
    # Start session
    print_header("Step 0: Initialize with observations")
    
    result = session.start(
        user_observations=user_obs if user_obs else None,
        xml_path=xml_path,
    )
    
    if result.get("datalog_summary"):
        print(f"\n  Datalog parsed successfully")
        # Print a compact version
        lines = result["datalog_summary"].split("\n")
        for line in lines[:5]:
            print(f"    {line}")
    
    print(f"\n  Observations loaded: {result['observations_loaded']}")
    if result["observation_details"]:
        for obs_id, obs_val in result["observation_details"][:10]:
            obs = session.kb.observations.get(obs_id)
            label = obs.obs_label if obs else obs_id
            print(f"    • {obs_id} = {obs_val}  ({label[:50]})")
    
    print(f"\n  Initial entropy: {result['entropy']:.4f} bits")
    print(f"  Top hypothesis: {result['top_rc_label']} ({result['top_rc_prob']:.2%})")
    
    print_header("Ranked Root Cause Hypotheses")
    print_hypotheses(result["hypotheses"])
    
    print_header("Recommended Next Actions")
    print_actions(result["recommended_actions"])
    
    # Interactive loop
    step = 0
    while not session.state.resolved:
        step += 1
        
        print(f"\n{'─'*70}")
        print(f"  Enter action number (1-{len(result['recommended_actions'])}), ")
        print(f"  or 'q' to quit, 's' for session summary:")
        
        try:
            choice = input("  > ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        
        if choice.lower() == 'q':
            break
        
        if choice.lower() == 's':
            summary = session.get_session_summary()
            print(json.dumps(summary, indent=2))
            continue
        
        try:
            action_idx = int(choice) - 1
        except ValueError:
            print("  Invalid input.")
            continue
        
        actions = result["recommended_actions"]
        if action_idx < 0 or action_idx >= len(actions):
            print("  Invalid action number.")
            continue
        
        selected = actions[action_idx]
        if selected["action_id"] is None:
            print("  No valid action to perform.")
            break
        
        # Show outcomes for user to pick
        outcomes = session.get_action_outcomes(selected["action_id"])
        print(f"\n  Performing: {selected['action_label']}")
        print(f"  What was the outcome?")
        for i, outcome in enumerate(outcomes, 1):
            print(f"    {i}. {outcome}")
        
        try:
            outcome_choice = input("  > ").strip()
            outcome_idx = int(outcome_choice) - 1
        except (ValueError, EOFError, KeyboardInterrupt):
            print("  Invalid input.")
            continue
        
        if outcome_idx < 0 or outcome_idx >= len(outcomes):
            print("  Invalid outcome number.")
            continue
        
        selected_outcome = outcomes[outcome_idx]
        
        # Register outcome
        print_header(f"Step {step}: {selected['action_label']} → {selected_outcome}")
        
        result = session.register_outcome(selected["action_id"], selected_outcome)
        
        print(f"\n  Entropy: {result['entropy']:.4f} bits (Δ = {result['entropy_reduction']:+.4f})")
        print(f"  Top hypothesis: {result['top_rc_label']} ({result['top_rc_prob']:.2%})")
        print(f"  Active hypotheses: {result['active_hypotheses']} | Eliminated: {result['eliminated_count']}")
        
        print_hypotheses(result["hypotheses"])
        
        if result["status"] == "resolved":
            res = result["resolution"]
            print_header("RESOLVED")
            print(f"  Root cause: {res['label']}")
            print(f"  Confidence: {res['confidence']:.2%}")
            print(f"  Steps taken: {res['steps_taken']}")
            break
        
        print_actions(result["recommended_actions"])
    
    # Final summary
    print_header("Session Summary")
    summary = session.get_session_summary()
    print(f"  Steps: {summary['steps']}")
    print(f"  Resolved: {summary['resolved']}")
    print(f"  Final entropy: {summary['final_entropy']:.4f} bits")
    print(f"  Actions performed: {len(summary['actions_performed'])}")
    print(f"  Eliminated RCs: {summary['eliminated_rcs']}")


def run_automated_demo(kb_dir: str, xml_path: str = None, error_codes: List[str] = None, action_catalogue_path: str = None):
    """Run a non-interactive demo that simulates a realistic diagnostic scenario."""
    
    print_header("Canon Ink Subsystem — Automated Demo")
    
    session = DiagnosticSession(kb_dir=kb_dir, lookback_days=90, action_catalogue_path=action_catalogue_path)
    print(f"\n{session.kb.summary()}")
    ts = session.tuning_stats
    print(f"  Likelihood tuning: tier1={ts['tier1']}, tier2={ts['tier2']}, tier3(placeholder)={ts['tier3']}")
    
    user_obs = [(code, "present") for code in (error_codes or [])]
    
    result = session.start(
        user_observations=user_obs if user_obs else None,
        xml_path=xml_path,
    )
    
    print(f"\n  Observations loaded: {result['observations_loaded']}")
    if result["observation_details"]:
        for obs_id, obs_val in result["observation_details"][:10]:
            obs = session.kb.observations.get(obs_id)
            label = obs.obs_label if obs else obs_id
            print(f"    • {obs_id} = {obs_val}  ({label[:60]})")
    
    print(f"\n  Initial entropy: {result['entropy']:.4f} bits")
    print(f"  Top RC: {result['top_rc_label']} ({result['top_rc_prob']:.2%})")
    
    print_hypotheses(result["hypotheses"], max_show=8)
    print_actions(result["recommended_actions"])
    
    # Simulate up to 5 steps, always picking top action
    # Alternate: pick 'fail' for verification (problem found), 'not_resolved' for resolution
    # This simulates a technician working through checks that narrow down the issue
    outcome_strategy = {
        "verification": lambda outcomes: (
            "fail" if "fail" in outcomes 
            else outcomes[1] if len(outcomes) > 1 
            else outcomes[0]
        ),
        "resolution": lambda outcomes: (
            "not_resolved" if "not_resolved" in outcomes 
            else outcomes[-1] if len(outcomes) > 1 
            else outcomes[0]
        ),
    }
    
    for step in range(1, 6):
        actions = result["recommended_actions"]
        if not actions or actions[0]["action_id"] is None:
            print(f"\n  Step {step}: No more actions available.")
            break
        
        top_action = actions[0]
        action_type = top_action.get("action_type", "verification")
        
        # Pick outcome based on strategy
        outcomes = top_action["outcomes"]
        picker = outcome_strategy.get(action_type, lambda o: o[0])
        selected_outcome = picker(outcomes)
        
        print(f"\n{'─'*70}")
        print(f"  Step {step}: {top_action['action_label'][:55]}")
        print(f"  Outcome: {selected_outcome}")
        
        result = session.register_outcome(top_action["action_id"], selected_outcome)
        
        print(f"  Entropy: {result['entropy']:.4f} (Δ={result['entropy_reduction']:+.4f})")
        print(f"  Top: {result['top_rc_label']} ({result['top_rc_prob']:.2%})")
        print(f"  Active: {result['active_hypotheses']} | Eliminated: {result['eliminated_count']}")
        
        print_hypotheses(result["hypotheses"], max_show=5)
        
        if result["status"] == "resolved":
            res = result["resolution"]
            print_header("RESOLVED")
            print(f"  Root cause: {res['label']}")
            print(f"  Confidence: {res['confidence']:.2%}")
            print(f"  Steps taken: {res['steps_taken']}")
            break
    
    print_header("Session Summary")
    summary = session.get_session_summary()
    print(f"  Total steps:        {summary['steps']}")
    print(f"  Resolved:           {summary['resolved']}")
    print(f"  Final entropy:      {summary['final_entropy']:.4f} bits")
    print(f"  Actions performed:  {len(summary['actions_performed'])}")
    print(f"  Eliminated RCs:     {summary['eliminated_rcs']}")
    print(f"\n  Entropy trajectory:")
    for h in summary["history"]:
        print(f"    Step {h['step']:>2}: H={h['entropy']:.4f}  top={h['top_rc'][:40]} ({h['top_prob']:.2%})")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Canon Ink Subsystem Diagnostic Reasoner")
    parser.add_argument("--kb-dir", default="/mnt/project", help="Path to KB JSON files")
    parser.add_argument("--actions", default=None, help="Path to tuned action catalogue JSON (overrides default)")
    parser.add_argument("--xml", default=None, help="Path to datalog XML file")
    parser.add_argument("--error", action="append", default=[], help="Error code(s) to inject")
    parser.add_argument("--auto", action="store_true", help="Run automated (non-interactive) demo")
    
    args = parser.parse_args()
    
    if args.auto:
        run_automated_demo(args.kb_dir, args.xml, args.error, args.actions)
    else:
        run_demo(args.kb_dir, args.xml, args.error, args.actions)
