"""
Likelihood Tuner
Applies calibrated P(outcome | RC) values to the action catalogue
based on a three-tier scheme:

Tier 1 — SDS tests (machine readings, near-deterministic):
  1 RC:    P(abnormal|linked)=0.95, P(normal|linked)=0.05
  2-3 RCs: P(abnormal|linked)=0.85, P(normal|linked)=0.10, P(inconcl|linked)=0.05
  4 RCs:   P(abnormal|linked)=0.75, P(normal|linked)=0.15, P(inconcl|linked)=0.10
  All:     P(abnormal|unlinked)=0.03, P(normal|unlinked)=0.95, P(inconcl|unlinked)=0.02

Tier 2 — Narrow-scope manual checks (1-2 linked RCs, pass/fail/inconclusive):
  1 RC:  P(fail|linked)=0.90, P(pass|linked)=0.05, P(inconcl|linked)=0.05
         P(fail|unlinked)=0.03, P(pass|unlinked)=0.92, P(inconcl|unlinked)=0.05
  2 RCs: P(fail|linked)=0.80, P(pass|linked)=0.10, P(inconcl|linked)=0.10
         P(fail|unlinked)=0.05, P(pass|unlinked)=0.87, P(inconcl|unlinked)=0.08

Tier 3 — Everything else: stays on uniform placeholders.

Each tuned entry is tagged with estimate_source = "calibrated_tier1" or "calibrated_tier2".
"""

from typing import Dict, List, Set


# SDS actions have non-standard outcome labels. Map the "abnormal" outcome per action.
# key: action_id prefix or full id -> index of the abnormal outcome in possible_outcomes
SDS_ABNORMAL_OUTCOME_INDEX = {
    # For 2-outcome SDS tests, index 1 is the abnormal one:
    # ['Not Expired', 'Expired'] -> 'Expired' is abnormal
    # ['Safe', 'Not safe'] -> 'Not safe' is abnormal
    # ['Supported', 'Not supported'] -> 'Not supported'
    # ['Installed', 'Not installed'] -> 'Not installed'
    # ['Detects Ink', 'Does not detect Ink'] -> 'Does not detect Ink'
    # ['Ink detected; ...', 'Ink not detected; ...'] -> 'Ink not detected'
    # ['Active (1)...', 'Inactive (0)...'] -> 'Inactive'
    # ['LED is ON', 'LED is OFF'] -> 'LED is OFF'
    # ['1 = solenoid activated', '0 = not activated'] -> '0 = not activated'
    # ['Functioning', 'Not functioning'] -> 'Not functioning'
    # For 3-outcome (pass/fail/inconclusive): 'fail' is abnormal
    "default_2_outcome": 1,  # second outcome is abnormal for all 2-outcome SDS tests
    "default_3_outcome_abnormal": "fail",
}

# Tier 2 target: CHK actions with <=5 linked RCs and global outcome set
TIER2_MAX_LINKED_RCS = 5


def tune_action_likelihoods(actions: List[Dict], all_rc_ids: Set[str]) -> int:
    """
    Apply calibrated outcome likelihoods to actions in-place.

    Args:
        actions: List of action dicts (from action catalogue JSON)
        all_rc_ids: Set of all RC IDs in the registry

    Returns:
        Number of actions tuned.
    """
    tuned = 0

    for action in actions:
        linked = action.get("linked_rc_ids", [])
        if isinstance(linked, str):
            # Still PENDING — skip
            continue

        linked_set = set(linked)
        outcomes = action.get("possible_outcomes", [])
        if len(outcomes) < 2:
            continue

        aid = action["action_id"]
        is_sds = aid.startswith("ACT_SDS_")
        is_chk = aid.startswith("ACT_CHK_")
        is_global = action.get("uses_global_outcome_set", False)
        n_linked = len(linked_set)

        # --- Tier 1: SDS tests with mapped RCs ---
        if is_sds and n_linked > 0:
            new_likelihoods = _build_sds_likelihoods(
                outcomes, linked_set, all_rc_ids, n_linked
            )
            action["outcome_likelihoods"] = new_likelihoods
            action["likelihood_source"] = "calibrated_tier1"
            tuned += 1
            continue

        # --- Tier 2: Narrow-scope CHK with pass/fail/inconclusive ---
        if (
            is_chk
            and is_global
            and 0 < n_linked <= TIER2_MAX_LINKED_RCS
            and set(outcomes) == {"pass", "fail", "inconclusive"}
        ):
            new_likelihoods = _build_chk_likelihoods(
                linked_set, all_rc_ids, n_linked
            )
            action["outcome_likelihoods"] = new_likelihoods
            action["likelihood_source"] = "calibrated_tier2"
            tuned += 1
            continue

        # --- Tier 3: Broad-scope or unlinked — patch uniform placeholders ---
        has_uniform = any(
            e.get("estimate_source") == "uniform_placeholder"
            for e in action.get("outcome_likelihoods", [])
        )
        if has_uniform and n_linked > 0:
            new_likelihoods = _build_placeholder_likelihoods(
                outcomes, linked_set, all_rc_ids, action.get("action_type", "")
            )
            action["outcome_likelihoods"] = new_likelihoods
            action["likelihood_source"] = "placeholder_discriminating"
            tuned += 1

    return tuned


def _build_sds_likelihoods(
    outcomes: List[str],
    linked: Set[str],
    all_rcs: Set[str],
    n_linked: int,
) -> List[Dict]:
    """Build likelihoods for SDS tests (Tier 1)."""

    # Determine linked/unlinked probability profiles based on RC count
    if n_linked == 1:
        p_abnormal_linked = 0.95
        p_normal_linked = 0.05
    elif n_linked <= 3:
        p_abnormal_linked = 0.85
        p_normal_linked = 0.10
    else:
        p_abnormal_linked = 0.75
        p_normal_linked = 0.15

    p_abnormal_unlinked = 0.03
    p_normal_unlinked = 0.95

    # Identify which outcome is "abnormal" vs "normal"
    if len(outcomes) == 2:
        normal_outcome = outcomes[0]
        abnormal_outcome = outcomes[1]
        outcome_map_linked = {
            normal_outcome: p_normal_linked,
            abnormal_outcome: p_abnormal_linked,
        }
        outcome_map_unlinked = {
            normal_outcome: p_normal_unlinked,
            abnormal_outcome: p_abnormal_unlinked,
        }
    elif len(outcomes) == 3 and "fail" in outcomes:
        # pass/fail/inconclusive
        p_inconcl_linked = 1.0 - p_abnormal_linked - p_normal_linked
        p_inconcl_unlinked = 1.0 - p_abnormal_unlinked - p_normal_unlinked
        outcome_map_linked = {
            "pass": p_normal_linked,
            "fail": p_abnormal_linked,
            "inconclusive": max(p_inconcl_linked, 0.01),
        }
        outcome_map_unlinked = {
            "pass": p_normal_unlinked,
            "fail": p_abnormal_unlinked,
            "inconclusive": max(p_inconcl_unlinked, 0.01),
        }
    else:
        # Fallback for unexpected outcome shapes
        n = len(outcomes)
        outcome_map_linked = {o: 1.0 / n for o in outcomes}
        outcome_map_unlinked = {o: 1.0 / n for o in outcomes}

    likelihoods = []
    for rc_id in all_rcs:
        is_linked = rc_id in linked
        probs = outcome_map_linked if is_linked else outcome_map_unlinked
        for outcome_label, prob in probs.items():
            likelihoods.append({
                "rc_id": rc_id,
                "outcome_label": outcome_label,
                "probability": round(prob, 4),
                "estimate_source": "calibrated_tier1",
            })
    return likelihoods


def _build_chk_likelihoods(
    linked: Set[str],
    all_rcs: Set[str],
    n_linked: int,
) -> List[Dict]:
    """Build likelihoods for narrow-scope CHK actions (Tier 2)."""

    if n_linked <= 1:
        probs_linked = {"fail": 0.90, "pass": 0.05, "inconclusive": 0.05}
        probs_unlinked = {"fail": 0.03, "pass": 0.92, "inconclusive": 0.05}
    elif n_linked == 2:
        probs_linked = {"fail": 0.80, "pass": 0.10, "inconclusive": 0.10}
        probs_unlinked = {"fail": 0.05, "pass": 0.87, "inconclusive": 0.08}
    else:
        # 3-5 RCs: softer but still discriminating
        probs_linked = {"fail": 0.70, "pass": 0.15, "inconclusive": 0.15}
        probs_unlinked = {"fail": 0.05, "pass": 0.87, "inconclusive": 0.08}

    likelihoods = []
    for rc_id in all_rcs:
        is_linked = rc_id in linked
        probs = probs_linked if is_linked else probs_unlinked
        for outcome_label, prob in probs.items():
            likelihoods.append({
                "rc_id": rc_id,
                "outcome_label": outcome_label,
                "probability": round(prob, 4),
                "estimate_source": "calibrated_tier2",
            })
    return likelihoods


def _build_placeholder_likelihoods(
    outcomes: List[str],
    linked: Set[str],
    all_rcs: Set[str],
    action_type: str,
) -> List[Dict]:
    """Build mildly discriminating placeholder likelihoods (Tier 3)."""

    n = len(outcomes)
    if n < 2:
        return []

    if action_type == "verification" and set(outcomes) == {"pass", "fail", "inconclusive"}:
        probs_linked = {"fail": 0.55, "pass": 0.30, "inconclusive": 0.15}
        probs_unlinked = {"fail": 0.10, "pass": 0.80, "inconclusive": 0.10}
    elif action_type == "resolution" and "resolved" in outcomes and "not_resolved" in outcomes:
        if "partially_resolved" in outcomes:
            probs_linked = {"resolved": 0.60, "partially_resolved": 0.20, "not_resolved": 0.20}
            probs_unlinked = {"resolved": 0.08, "partially_resolved": 0.07, "not_resolved": 0.85}
        else:
            probs_linked = {"resolved": 0.65, "not_resolved": 0.35}
            probs_unlinked = {"resolved": 0.05, "not_resolved": 0.95}
    else:
        # Generic: first outcome = "good", rest = split
        probs_linked = {}
        probs_unlinked = {}
        for i, o in enumerate(outcomes):
            if i == 0:
                probs_linked[o] = 0.5
                probs_unlinked[o] = 0.2
            else:
                probs_linked[o] = 0.5 / (n - 1)
                probs_unlinked[o] = 0.8 / (n - 1)

    likelihoods = []
    for rc_id in all_rcs:
        is_linked = rc_id in linked
        probs = probs_linked if is_linked else probs_unlinked
        for outcome_label, prob in probs.items():
            likelihoods.append({
                "rc_id": rc_id,
                "outcome_label": outcome_label,
                "probability": round(prob, 4),
                "estimate_source": "placeholder_discriminating",
            })
    return likelihoods
